# mcis6273-f23-datamining
**Zetero UserName: mktulasi**

**GitHub UserName: mktulasi**

***repo Link: https://github.com/mktulasi/mcis6273_f23_datamining***

